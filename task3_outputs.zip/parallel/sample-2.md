# sample-2.txt

## Group 1

**Hindi:** गढ़ मुक्तेश्वर का वर्णन शिव पुराण में मिलता है। शिव बल्लभपुर नामक स्थान में शिव निवास करते हैं। शिव बल्लभपुर क्षेत्र मुझे काशी के समान प्रिय है। शिव बल्लभपुर शिवजी को अति प्रिय है। उसे मीराबाई की रेती के नाम से जाना जाता है।

**English:** Garh 93C Mukteshwar is described in the Shiva Purana. A place called Shiv Ballabhpur is inhabited by Shiva. Shiv Ballabhpur area is as dear to me as Kashi. Shiv Ballabhpur is very dear to Shiva. It is known as Mirabai ki Reti.

## Group 2

**Hindi:** ऐसी मान्यता है कि एक बार मीराबाई यहाँ गंगा स्नान के लिए आई थीं। अब गंगा का तट इस मंदिर से लगभग 10 किलोमीटर दूर है। गंगा तट पर शिव बल्लभपुर नामक एक स्थान है। शिव बल्लभपुर जम्बूद्वीप के आर्यावर्त देश में हस्तिनापुर की पूर्व दिशा में स्थित है। हस्तिनापुर का ऐतिहासिक महत्व है।

**English:** It is believed that once Mirabai came here to take a bath in the Ganges. Now the bank of the Ganges is about 10 kilometers away from this temple. There is a place called Shiv Ballabhpur on the bank of the Ganges. Shiv Ballabhpur is located in the eastern direction of Hastinapur in the Aryavarta country of Jambudvipa. Hastinapur has historical importance.

## Group 3

**Hindi:** प्रथा है कि बद्रीनाथ मंदिर को केवल आरती के समय ही खोला जाता है। यह मंदिर साल में केवल एक बार अक्षय तृतीया को परशुराम जयंती पर दिन भर दर्शनार्थियों के लिए खोला जाता है। मेला गंगा के किनारे लगभग 11 किलोमीटर के क्षेत्र में लगता है। मेला स्थल दिल्ली से लगभग 90 किलोमीटर पड़ता है। अनेक लोग भैंसा, बुग्गी, ट्रैक्टर, ट्रॉलियों, कार और अन्य साधनों से मेला स्थल तक पहुँचते हैं।

**English:** It is customary that the Badrinath temple is opened only at the time of Aarti. The temple is open for day-long visitors only once a year on Akshaya Tritiya, Parshuram Jayanti. The mela takes place in an area of about 11 km along the Ganges. The mela site is about 90 km from Delhi. Many people reach the mela site by buffalo, buggy, tractors, trolleys, cars and other means.

## Group 4

**Hindi:** यूँ तो यहाँ खाने पीने का सामान बहुत सी दुकानों में मिल जाता है। मेला स्थल, कार आदि से आराम से पहुँचा जा सकता है। इस वर्ष मेले का आयोजन मेला स्थल को 20 सेक्टरों में बाँट कर किया जा रहा है। जैन जगत से उत्तर भारत वर्ष की सम्पूर्ण जातियों के लिए विशेष महत्व है। कार्तिक पूर्णिमा के अवसर पर गढ़ मुक्तेश्वर में गंगा तट पर लगने वाला मेला विशालतम मेलों में से एक है।

**English:** Food and drinks can be found in many shops here. One can easily reach from the fair venue, car etc. This year the fair is being organized by dividing the fair venue into 20 sectors. From the Jain world, North India is of special importance for all the castes of the year. The fair on the banks of the Ganges at Garh Mukteshwar on the occasion of Kartik Purnima is one of the largest fairs.

## Group 5

**Hindi:** गंगा तट के रेतीले मैदान में मेला लगता है, किंतु गढ़ मुक्तेश्वर के गंगा मंदिर में अब 86 सीढ़ियाँ ही बची हैं। मेले के दौरान तट पर तंबुओं का एक पूरा नगर बस जाता है, लेकिन अब यातायात के कई साधन उपलब्ध हैं। मेले के अलावा सामान्य दिनों में आने वाले लोग ब्रज घाट के आसपास बनी धर्मशालाओं में ठहरते हैं। ज्यादातर श्रद्धालु लगाए गए टेंटों में ही ठहरते हैं। बताते हैं कि 1937 तक गंगा जी गढ़ मुक्तेश्वर के गंगा मंदिर की सीढ़ियों को छूते हुए बहती थीं।

**English:** The fair takes place in the sandy plain of the Ganges bank, but the Ganges temple at Garh Mukteshwar now has only 86 steps left. An entire town of tents is settled on the banks during the fair, but many means of transport are now available. Apart from the fair, visitors on normal days stay in dharamshalas built around the Braj Ghat. Most devotees stay in tents. It is said that till 1937, the Ganges flowed touching the steps of the Ganges temple at Garh Mukteshwar.

## Group 6

**Hindi:** गढ़ मुक्तेश्वर के गंगा मंदिर में पहुँचने के लिए कभी 101 सीढ़ियाँ हुआ करती थीं। लेकिन धीरे धीरे गंगा जी स्थान छोड़ती चली गईं। गढ़ मुक्तेश्वर में स्थित गंगा मंदिर काफी ऊँचाई पर बना हुआ है। अनुमान है कि हर साल करीब बीस लाख लोग गढ़ मुक्तेश्वर मेले के दौरान गंगा स्नान करने आते हैं। गढ़ मुक्तेश्वर के गंगा मंदिर में गंगा मैया के अतिरिक्त ब्रह्मा जी की मूर्ति भी लगी हुई है।

**English:** There used to be 101 steps to reach the Ganga temple at Garh Mukteshwar. But gradually Ganga ji started leaving the place. The Ganga temple at Garh Mukteshwar is built at a great height. It is estimated that about two million people come to take a bath in the Ganga during the Garh Mukteshwar Mela every year. The Ganga temple at Garh Mukteshwar also has an idol of Brahma Ji besides Ganga Maiya.

## Group 7

**Hindi:** गढ़ मुक्तेश्वर के गंगा मंदिर में एक ऐसा पत्थर भी है, जिसे ध्यानपूर्वक देखने से उस पर भगवान शिव की आकृति का आभास होता है। गंगा तट पर बसा शिव, बल्लभपुर, देवों, ऋषियों और पितरों को संतोष देने वाला है। कहते हैं कि एक बार पार्वती जी ने शंकर जी से प्रश्न किया। उस वक्त गंगा की धारा के साथ बहते। अगले दिन प्रात पूर्णमासी को सभी ने गंगा स्नान कर पूजा, अर्चना, कथा आदि की प्रत्येक वर्ष लाखों की संख्या में श्रद्धालु गढ़ मुक्तेश्वर, कार्तिक पूर्णिमा पर कलुष, विनाशनी, पापहरिणी, गंगा में स्नान करने और अपने स्वजनों की आत्मा की शांति के लिए यहाँ दीप दान करने आते हैं।

**English:** The Ganga temple at Garh Mukteshwar also has a stone on which one can see the image of Lord Shiva on it. Situated on the banks of the Ganges, Shiva, Ballabhpur, is said to satisfy the gods, sages and ancestors. Once Parvati ji questioned Shankar ji. At that time, the river flowed with the flow of the Ganges. The next day on Purnima everyone took a bath in the Ganges and every year lakhs of devotees come here to take a bath in the Garh, Archana, Katha, etc. On Mukteshwar, Kartik Purnima, Kalusha, Vanashani, Papaharini, Ganga and to donate lamps for the peace of the souls of their relatives.

## Group 8

**Hindi:** एकादशी से चतुर्दशी तक गढ़ मुक्तेश्वर में महाभारत युद्ध में मारे गए सभी लोगों की आत्मा की शांति के लिए यज्ञ किया गया। चतुर्दशी की संध्या को यज्ञ की समाप्ति पर उन आत्माओं को गंगा में दीप दान कर श्रद्धांजलि अर्पित की गई। चतुर्दशी की शाम को असंख्य लोग अपने स्वजनों को श्रद्धांजलि देने के लिए गंगा में दीप दान करते हैं। दीपों का दृश्य बड़ा ही शांतिदायक और मनोहारी प्रतीत होता है। सतयुग में सभी तीर्थ पुण्य का फल देते हैं।

**English:** From Ekadashi to Chaturdashi, a yajna was performed at Garh Mukteshwar for the peace of the souls of all those killed in the Mahabharata war. On the evening of Chaturdashi, at the end of the yajna, tributes were paid to those souls by lighting lamps in the Ganges. On the evening of Chaturdashi, innumerable people donate lamps in the Ganges to pay homage to their relatives. The view of the lamps seems very peaceful and charming. In the Satayuga, all the Tirthas bear the fruits of virtue.

## Group 9

**Hindi:** त्रेता में, पुष्कर, द्वापर में कुरुक्षेत्र तीर्थ पुण्य का फल देते हैं और कलिकाल में केवल गंगा स्नान से पुण्य फल की प्राप्ति है। गंगा स्नान के लिए अनेक घाट भी बनाए गए हैं। प्रमुख स्थानों पर क्लोज, सर्किट, टीवी कैमरे भी लगाए गए हैं। गढ़ मुक्तेश्वर में पहले मेला स्थल तक लोगों को पैदल ही चलकर जाना पड़ता था। सुरक्षा के लिहाज से गढ़ मुक्तेश्वर में पहले के मुकाबले पुलिस फोर्स ज्यादा लगाई गई है, पर समूह के रूप में मेले में आने वाले श्रद्धालु अपने भोजन आदि की व्यवस्था स्वयं ही करते हैं।

**English:** In Treta, Pushkar, Dwapar, Kurukshetra Tirtha gives the fruits of virtue and in Kalikal, only Ganga Snan brings the fruits of virtue. Several ghats have also been built for Ganga Snan. Closed, circuit, TV cameras have also been installed at prominent places. In Garh Mukteshwar, people had to walk till the first mela site. For security, Garh Mukteshwar has more police force than before, but devotees coming to the mela in groups arrange their own food etc.

## Group 10

**Hindi:** वे ऐसा क्या कर्म करें, जिससे उन्हें आपका स्नेह मिले। इस पर शंकर जी कहा कि हे देवी। प्रभु ऐसा कोई उपाय और स्थान बताएँ, जिससे संसार में अनेक व्याधियों और पापों से त्रस्त जीव को मुक्ति मिले। गढ़ मुक्तेश्वर में धार्मिक महत्व की कई जगहें हैं, जैसे नहुष, कूप, नक्का, कुआँ, मुक्तेश्वर, महादेव का मंदिर, बद्रीनाथ मंदिर आदि मेले में भाग लेने आए। मुक्तेश्वर महादेव मंदिर के सामने विशाल रेतीला मैदान है।

**English:** To this, Shankara said, "O Goddess. May the Lord give some remedy and place so that the creature suffering from many diseases and sins in the world may be freed. Garh Mukteshwar has many places of religious importance, such as Nahush, Kup, Nakka, Kuan, Mukteshwar, Mahadev's temple, Badrinath temple, etc. There is a huge sandy ground in front of the Mukteshwar Mahadev temple.