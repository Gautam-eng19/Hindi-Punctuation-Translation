# sample-6.txt

## Group 1

**Hindi:** यू, नो। ऐक्चुली। ऐक्चुली, मुझे नींद नहीं आ रही थी। मेरे डैड कहा करते थे कि मर्द का सिर सिर्फ तीन औरतों के सामने झुकता है। अपनी मां के सामने, एक दुर्गा, मां के सामने और राहुल।

**English:** Uh, no. Actulli. Actulli, I couldn't sleep. My dad used to say that a man's head bowed before only three women. In front of his mother, one Durga, in front of his mother, and Rahul.

## Group 2

**Hindi:** राहुल, तुम्हारा सबसे अच्छा दोस्त है। राहुल सिर्फ तुमसे प्यार करता है। ऐसा लगता है कि तुम मुझसे प्यार नहीं करती, तुम उससे प्यार नहीं करती। मैं पर क्या तुम उससे प्यार करती हो? तुम कब से जानती हो?

**English:** Rahul, your best friend. Rahul just loves you. It's like you don't love me, you don't love him. Do you love him over me? How long have you known?

## Group 3

**Hindi:** तुम खुश हो, बेटी। मैं नहीं चाहती कि तुम खुश रहो। तुम अगर चाहो ना तो तुम्हें कोई भी लड़का मिल सकता है। अमन बहुत अच्छा लड़का है। मुझसे बहुत प्यार करता है।

**English:** You are happy, daughter. I don't want you to be happy. If you don't want to, you can have any boy. Aman is a very nice boy. He loves me very much.

## Group 4

**Hindi:** प्यार के नहीं, वो घर नहीं होता है। अमन, पता नहीं कौन फोन पर है। मैंने कितनी बार सोचा कि उसको जाकर कह दूं। मैंने कभी नहीं सोचा था कि मैं कभी किसी को ये कहूंगा। और मैंने सोचा कि तुम्हें भी नहीं आ रही होगी।

**English:** Not of love, it's not home. Aman, I don't know who's on the phone. How many times have I thought of going and telling him. I never thought I'd ever tell anyone this. And I thought you wouldn't be coming either.

## Group 5

**Hindi:** और अगर तुम जाग रही होगी, तो मेरे बारे में ही सोच रही होगी। अमन, तुम जानते हो। मैं जानता हूं। मैं भी मां हूं। मैं हर साल समर कैंप जाती हूं।

**English:** And if you're awake, you're thinking of me. Aman, you know. I know. I'm also a mother. I go to summer camp every year.

## Group 6

**Hindi:** तुम कोई समरकैंप, वमरकैंप नहीं जा रही हो। मुझे छोड़ कर जा रही हो। कॉलेज छोड़ कर जा रही हो। तुम मुझे इस तरह छोड़ कर मत जाया करो। मुझे बताया भी नहीं।

**English:** You're not going to summercamp, summercamp. You're leaving me. You're leaving college. You don't leave me like this. You didn't even tell me.

## Group 7

**Hindi:** मेरा पहला प्यार अधूरा रह गया। दूसरे, कॉलेज के स्टूडेंट्स देखते ही रह जाएंगे। शिमला अपने समरकैंप ऑफ्कोर्स, मैं खुश हूं और मालूम है। तुम बहुत खूबसूरत हो, क्योंकि तुम सबसे ज्यादा अलग हो। तुम्हें नहीं लगता।

**English:** My first love was left unfulfilled. Secondly, college students will be left watching. Shimla with its summer camp off course, I am happy and know. You are very beautiful, because you are the most different. You don't think.

## Group 8

**Hindi:** तुम्हें और कोई नहीं मिला। अंजलि, मैं तुम्हें ही मिलने आ रहा था। तुम मैं तुम्हारी तरह खूबसूरत लगना चाहती थी। तुमने उससे अपने दिल की बात कह दी। आई होप, मैं उसको ये सब कह पाऊं।

**English:** You didn't find anyone else. Anjali, I was just coming to meet you. You wanted me to look beautiful like you. You told her your heart. I hope I can tell her all this.

## Group 9

**Hindi:** राहुल, ये तुम क्या कर रहे हो? तुम मुझसे कोई भी बात छुपा नहीं सकती हो। मां, ऐक्चुली राहुल की जगह कोई और होता, तब भी शायद मुझे इतना ही बुरा लगता। मां, शायद मुझसे फिर से न हो, इसे एक समझौता ही समझ लो। ना, मेरी बेटी समझौता करेगी, और प्यार नहीं करेगी।

**English:** Rahul, what are you doing? You can't hide anything from me. Mama, if someone else were in Rahul's place, maybe I would still feel so bad. Mama, maybe not with me again. Think of it as a compromise. No, my daughter will compromise, and not love.

## Group 10

**Hindi:** प्यार तो मैंने कर लिया है। अंजलि, तुमसे कुछ पूछूं। अंजलि राहुल को। लेकिन राहुल अंजलि की शादी दिसंबर से पहले नहीं हो सकती है। अंजलि तुम्हारा फोन है।

**English:** Love is what I have done. Anjali, let me ask you something. Anjali to Rahul. But Rahul Anjali's wedding may not take place before December. Anjali is your phone.

## Group 11

**Hindi:** तुम्हारा घर बस जाए। तुम जाओ। तुम यहां इस वक्त मैं वापस नहीं आ रही। मेरी सगाई हो गयी है। अब तो वो बच्चे मेरी जिंदगी का एक हिस्सा बन चुके हैं।

**English:** Stay at your house. You go. You're not coming back here right now. I'm engaged. Now those kids are a part of my life.

## Group 12

**Hindi:** राहुल, यह कैसा सवाल है? मेरी एक छोटी सी प्रॉब्लम है, लेकिन वो घर जो समझौते के बलबूते पर बना हो। वहां पर बहुत बर्फ पड़ती है। तारे को देखकर कुछ मांगो, ना, तो मिल जाता है। लेकिन मुझे तो कुछ आता ही नहीं।

**English:** Rahul, what kind of question is this? I have a small problem, but the house that is built on the basis of the agreement. There is a lot of snow. Ask for something when you see the star. No, you get it. But I don't get anything.

## Group 13

**Hindi:** मुझे क्यों? क्या? कैसी लग रही हूं? कहते हैं, टूटते। उन बच्चों को सिंगिंग और डासिंग सिखाने।

**English:** Why me? What? How am I feeling? They say, break up. Teach those kids singing and dancing.

## Group 14

**Hindi:** ये तो मैंने कभी सोचा ही नहीं था। खुदा की रहमत तो सुना था, आज देख भी लिया। बच्ची की दुआ, कबूल हो गयी। रिफ़त दी। टीना।

**English:** I never thought of this. I heard God's mercy, I saw it today. The child's prayer was accepted. Ref. 93C. Tina.

## Group 15

**Hindi:** बेटा। बेटी मकान होता है। यहां पर काफी गर्मी है।

**English:** Son. Daughter is home. It is very hot here.