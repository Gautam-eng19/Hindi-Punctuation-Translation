# sample-4.txt

## Group 1

**Hindi:** अभी हाल ही में कुछ वर्ष पूर्व आनुवंशिक परिवर्तन genetic modification द्वारा अमेरिका में कपास के एक नए बीज का निर्माण किया गया, जो बीटी कॉटन सीड Bt। cotton seed के नाम से जाना जाता है। यह बीज कपास की फसल को बीमारियों और कीड़ों से बचाने की शक्‍ति प्रदान करता है। इसके उपयोग से अमेरिका और चीन में कपास के उत्पादन में काफी वृद्धि हुई है। सन 1967 में, हमारे वैज्ञानिकों ने कपास की पैदावार में बढ़ोत्‍तरी करने के लिए एक विशाल कार्यक्रम आरंभ किया, जिसके फलस्वरूप कुछ ही वर्षों में प्रति हेक्टेयर उत्पादन और कुल उत्पादन, दोनों में दुगने से ज्यादा की वृद्धि हुई।

**English:** Just a few years ago, genetic modification genetic modification created a new cotton seed in the United States, known as Bt cotton seed Bt cotton seed. This seed provides the power to protect the cotton crop from diseases and pests. Its use has significantly increased cotton production in the United States and China. In 1967, our scientists launched a massive program to increase cotton yields, resulting in more than double both per hectare production and total production in just a few years.

## Group 2

**Hindi:** कपास के उत्पादन के लिए प्रजनन breeding कार्यक्रम के माध्यम से कपास की प्रत्येक जाति में विभिन्न किस्में तैयार की गई हैं। गौसीपियम, हिर्सुटम, Gossypium Hirsutum इनमें से सबसे महत्‍त्वपूर्ण वानस्पतिक जाति है, जो मूल रूप से कंबोडिया तथा मैक्सिको में पाई जाती थी। परंतु अब यह अमेरिका के विशाल भाग में उगाई जाने लगी है। कपास की फसल में कई गुणों का होना आवश्यक है। इनमें से कुछ गुण इस प्रकार हैं, फसल का जल्दी तैयार होना, फसल में बीमारियों तथा कीड़े मकोड़ों से बचने की प्रतिरक्षा शक्‍ति का पर्याप्‍त मात्रा में होना, अधिक उपज देना, रेशों का अधिक मज़बूत होना, आदि।

**English:** Different varieties of cotton have been developed for cotton production through the Breeding Breeding Program. Gossypium, Hirsutum, Gossypium Hirsutum are the most important of these botanical species, originally found in Cambodia and Mexico. But now it has started to be grown in a large part of the Americas. The cotton crop needs to have many qualities. Some of these qualities are early crop preparation, adequate immunity to diseases and pests in the crop, high yielding, high strength of fibers, etc.

## Group 3

**Hindi:** अध्यापक ने बताया कि भारत में रेशम कीट पालन सन् 400 में शुरु हुआ था। अब विश्‍व में रेशम उत्पादन करने वाले देशों में भारत का प्रमुख स्थान है। 5 करोड़ से अधिक लोग रोज़गार में व्यस्त हैं तथा इसी से आजीविका चलाते हैं। राज्यों में प्रति एकड़ उत्पादन के हिसाब से महाराष्‍ट्र सबसे अग्रणी है, किंतु कुल उत्पादन में गुजरात सूची में सर्वोपरि है। किंतु उत्पादन में भारत का स्थान अमेरिका, रुस और चीन, जो सर्वाधिक उत्पादक देश हैं, के बाद चौथा है।

**English:** The teacher pointed out that sericulture in India started in the year 400. India now occupies a leading position among the silk producing countries in the world. More than 50 million people are engaged in employment and earn their livelihood from it. Maharashtra leads the states in terms of per acre production, but Gujarat tops the list in total production. But India ranks fourth in production after USA, Russia and China, which are the most productive countries.

## Group 4

**Hindi:** कृषि व्यवसाय की तरह रेशम कीट पालन भी जीविकोपार्जन का एक मुख्य साधन है, जिसमें कई हजार श्रमिक काम करते हुए यह बहुमूल्य रेशा पैदा करते हैं। रेशम कई प्रकार के कीड़ों द्वारा बनाया जाता है, परंतु इन सब में बांबिक्स मोरी Bombyx Mori जाति का रेशम कीड़ा ही प्रमुख है और सेरीकल्चर फार्म के विशेष वातारण में रेशम बनाता है। रेशम का कीड़ा देखने में तितली की तरह होता है, जिसके अंडों से पहले लारवा कैटरपिलर बनता है। फिर कैटरपिलर प्यूपा pupa अथवा क्राइसेलिस बनने की प्रक्रिया में अपनी सुरक्षा के लिए चारों तरफ रेशम से घर कठोरी बनाता है, जिसे कोया अथवा कोकून cocoon कहते हैं। क्राइसेलिस पूरा विकसित होने के पश्‍चात मॉथ moth के रूप में कोये से बाहर निकलता है, तथा फिर मादा मॉथ, रेशम कीट अंडे देती है।

**English:** Like agriculture, sericulture is a main means of livelihood, with several thousand workers working to produce this valuable fibre. Silk is made by a variety of insects, but the most prominent of these is the Bambix mori, the silkworm of the genus Bombyx mori, and makes silk in the special environment of the sericulture farm. The silkworm is similar to a butterfly, whose eggs first form a larval caterpillar. Then the caterpillar pupates and in the process of forming a pupa or chrysalis, makes a silkworm from all around, called a koya or cocoon cocoon. After the chrysalis is fully developed, the moth emerges from the nest as a moth, and then the female moth, the silkworm, lays eggs.

## Group 5

**Hindi:** प्रत्येक अंडे का आकार एक पिन हैड pin head के बराबर होता है, जिसमें एक नरम सा बिंदु होता है। इस नरम बिंदु के कारण ही कोकून को फूटने में आसानी होती है। गौसीपियम प्रजाति के अंतर्गत कपास की 36 जातियाँ मान्य हैं। परंतु अच्छे किस्म की कपास पैदा करने के लिए इनमें से केवल चार प्रकार की कपास की खेती की जाती है, क्योंकि अन्य जातियाँ जंगली हैं। कपास की सर्वोत्‍तम पैदावार के लिए गर्म, जलवायु, पर्याप्‍त, नमी तथा दोमट loamy मिट्टी के साथ साथ सिंचाई की भी अच्छी सुविधाएं होनी चाहिए।

**English:** Each egg is the size of a pinhead pinhead, with a soft point. This soft point makes it easier for the cocoon to hatch. There are 36 varieties of cotton recognized under the genus Gossypium. However, only four of these varieties are cultivated to produce good quality cotton, as the others are wild. For the best cotton yield, there must be warm, climatic, adequate, moist, loamy soil, as well as good irrigation facilities.

## Group 6

**Hindi:** कपास के खेतों के सौंदर्य का वर्णन शब्दों में करना कठिन है। कपास की खेती में लगभग 4। 5 सेंटीमीटर चौड़ा तथा 3। 8 सेंटीमीटर लंबा हो जाता है। बीजकोष के बीजों से निकले।

**English:** The beauty of cotton fields is difficult to describe in words. In cotton cultivation, it grows to about 4.5 cm wide\ u093C and 3.8 cm long.

## Group 7

**Hindi:** डा। जोशी ने छात्रों को बताया कि कपास एक बीज तंतु है, जो गौसीपियम Gossypium प्रजाति के पौधे से उगता है। बीजकोष बहुत जल्दी बढ़ता है तथा पकने पर इसका आकार 2। मानों। भारत में कपास की खेती का क्षेत्र दुनिया में सबसे अधिक करीब 80 लाख हेक्टेयर है और यही एकमात्र ऐसा देश है जहाँ कपास की चारों कृषि योग्य किस्मों की खेती की जाती है।

**English:** Dr. Joshi told the students that cotton is a seed fibre, which grows from a plant of the genus Gossypium Gossypium. The spore grows very quickly and is 2 in size when ripe. the values. India has the highest area under cotton cultivation in the world at about 8 million hectares and is the only country to cultivate all four cultivable varieties of cotton.

## Group 8

**Hindi:** क्षेत्र की जलवायु, मिट्टी के प्रकार एवं कपास की जाति व किस्म के आधार पर कपास की बुवाई अलग अलग समय पर की जाती है। उत्‍तरी भारत में कपास प्रायः मई के मध्य में बोई जाती है। कपास के रेशों के टेंट को दिसंबर माह में भारत में प्रायः हाथ से तथा विदेशों में मशीन से तोड़ा जाता है। इन कीड़ों की मादा मॉथ moth कोये से निकलने के तीन दिन बाद करीब 700 अंडे देती है और फिर मर जाती है। वैसे अन्य जाति के रेशम कीट 350, 400 अंडे देते हैं।

**English:** Cotton is sown at different times depending on the climate, soil type, and variety of cotton. Cotton in northern India is usually sown in mid-May. Cotton fibre tents are often broken by hand in India and machine in foreign countries in December. The female moth of these insects lays about 700 eggs and then dies three days after hatching. Similarly, other species of silkworms lay 350,400 eggs.

## Group 9

**Hindi:** ये अंडे बहुत ही हल्के होते हैं। इस कीड़े के लारवा larva शहतूत के पत्‍ते खाते हैं। इस बीज को भारतवर्ष में बोने की अनुमति हाल ही में मिली है। कपास की नई नई किस्में जारी की जा रहीं हैं, जिनमें उपरोक्‍त गुण विद्यमान हों। भारत में कपास के उत्पादन की कमी का प्रमुख कारण है कि यहाँ कपास की खेती वाले क्षेत्र में से केवल एक चौथाई हिस्से में ही सिंचाई की उचित सुविधा उपलब्ध है और शेष खेती वर्षा पर निर्भर करती है।

**English:** These eggs are very light. The larvae of this insect\ u093C eat mulberry leaves. This seed has recently received permission to be sown in India. New varieties of cotton are being released, which have the above qualities. The main reason for the lack of cotton production in India is that only one-fourth of the area under cotton cultivation has proper irrigation facilities and the rest is rainfed.

## Group 10

**Hindi:** कपास के पौधे की वृद्धि से लेकर फूल आने तक की अवस्था में ताप, सूरज की रोशनी तथा पानी की उपलब्धि आदि का अधिक प्रभाव पड़ता है। उदाहरण के लिए, यदि दिन व रात दोनों समय अधिक तापमान हो, तो फूल अवस्था देर से शुरु होती है। चार सप्‍ताह से छः सप्‍ताह के बीच फूलों में कलियाँ निकलना शुरु हो जातीं हैं, तथा रोपण के लगभग 100 दिन के बाद पौधे पर सफेद या हल्के अथवा गहरे पीले रंग के अतिसंवेदनशील फूल खिल जाते हैं। 50 से 80 दिन के पश्‍चात बीजकोष फट जाता है, तथा वर्ष के इस समय में नवंबर माह में, जब वह पूरी तरह खुल जाता है, तो हमें यह अद्‍भुत नजारा देखने को मिलता है। बुवाई के पश्‍चात बीज के उगने के बाद, जब मूल जड़ भूमि में प्रवेश करती है, तो पौधे की वृद्धि के लिए वह भूमि से अपना खाद्‍य पदार्थ लेना शुरु करती है।

**English:** The cotton plant's growth to flowering stage is more influenced by temperature, sunlight, and water availability. For example, if there is high temperature both day and night, the flowering stage begins late. Between four weeks and six weeks, the buds begin to bloom, and after about 100 days of planting, the plant blossoms white or light or dark yellow flowers. After 50 to 80 days, the spore bursts, and at this time of year, in November, when it is fully open, we get to see this wonderful sight. After sowing, when the seed germinates, when the root enters the ground, it begins to take its food from the ground for the plant's growth.

## Group 11

**Hindi:** इस प्रकार रेशम के कीड़े का जीवन चक्र पूरा हो जाता है। भारत ही एक ऐसा देश है, जहाँ कई प्रकार के रेशम के कीड़ों का पालन करके विविध प्रकार का रेशम प्राप्‍त किया जाता है। यह एक लघु उद्योग है, जिसमें 50 000 गाँव रेशम कीट पालन sericulture के कार्य में जुटे हुए हैं। उन्होंने बताया कि हम बांबिक्स, मोरी जाति के ही रेशम कीड़ों का पालन करते हैं। दो जातियों के गुणसूत्रों को मिलाकर अपनी इच्छानुसार संकर hybrid पौधे विकसित किए जा सकते हैं।

**English:** Thus the life cycle of silkworms\ u093C is completed. India is the only country where a variety of silkworms are obtained by rearing\ u093Cs. It is a small-scale industry with 50,000 villages engaged in sericulture. We follow silkworms\ u093Cs of Bambix, Mori species. The chromosomes of the two species can be combined to grow hybrid plants of our choice.

## Group 12

**Hindi:** ये 4 से 6 फुट ऊँचे पौधों पर सजावट की जादुई आकर्षण वाली कलाकृतियाँ हों। मानों स्वर्ग ने स्वयं ही इस धरा पर सफेदी बिखेर दी हो। ऐसा लग रहा था। हज़ारों रेशों की मुस्कराहट और चमक मन को मोह लेने वाली थी और ऐसा लगता था। स्वर्ण रंग का मूंगा रेशम केवल हमारे देश में ही पैदा किया जाता है।

**English:** May these be works of art with a magical charm of decoration on 4 to 6 feet high plants. It seemed as if heaven itself had scattered white on this earth. The smile and glow of Hajj\ u093Car fibers were captivating and it seemed. The golden colored coral silk is produced only in our country.

## Group 13

**Hindi:** यह मालवेसी Malvaceae परिवार का सदस्य है, जो बोलचाल की भाषा में मैलो Mallow परिवार के नाम से जाना जाता है।

**English:** It is a member of the family Malvaceae, colloquially known as the Malo mallow family.