# sample-3.txt

## Group 1

**Hindi:** चंद्र, प्रभु, दिगंबर जैन अतिशय क्षेत्र देहरा, तिजारा, राजस्थान के अलवर जिले में स्थित है। तिजारा का यह अतिशय क्षेत्र या कहें कि मंदिर अलवर जिले से 52 किलोमीटर और दिल्ली से 117 किलोमीटर की दूरी पर स्थित है। दिल्ली से हस्तिनापुर की दूरी तकरीबन 105 किलोमीटर है। यहाँ यह अतिशय क्षेत्र कहलाता है। तिजारा अतिशय क्षेत्र में चंद्र प्रभु भगवान की सफेद रंग की अत्यंत मनोहारी संगमरमर की मूर्ति स्थापित है।

**English:** Chandra, Prabhu, Digambar Jain Atishay Kshetra is located in Dehra, Tijara, Alwar district of Rajasthan. This Atishay Kshetra of Tijara or let us say the temple is located at a distance of 52 kilometres from Alwar district and 117 kilometres from Delhi. The distance from Delhi to Hastinapur is about 105 kilometres. This is called Atishay Kshetra. The Tijara Atishay Kshetra houses the most charming white marble statue of Lord Chandra Prabhu.

## Group 2

**Hindi:** यह संगमरमर मूर्ति इस क्षेत्र में कराई गई। अतिशय क्षेत्र तिजारा हस्तिनापुर को शास्त्रों में अन्य कई नामों से भी जाना जाता है, जैसे गजपुर, नागपुर, असंधिवत, ब्रह्मास्थल, शांतिनगर, कुजारपुर आदि ऐसी ही है। अतिशय का अर्थ है सामान्य से बहुत ज्यादा। इच्छा से ज्यादा मिलता है। हस्तिनापुर जाने के लिए हमने दिल्ली में कश्मीरी गेट बस अड्डे से जाना सुविधाजनक समझा।

**English:** This marble statue was made in this area. Atishay Kshetra Tijara Hastinapur is also known by many other names in the scriptures, such as Gajpur, Nagpur, Asandhvat, Brahmasthala, Shantinagar, Kujarpur, etc. Atishay means much more than usual. More than desired. To go to Hastinapur, we found it convenient to go from Kashmere Gate bus stand in Delhi.

## Group 3

**Hindi:** कश्मीरी गेट से लगातार मेरठ तक की बसें जाती हैं। फिर मेरठ से हस्तिनापुर की बसें मिल जाती हैं। हस्तिनापुर पहुँचे लोगों के ठहरने के लिए धर्मशाला का भी प्रबंध मिलता है। श्वेतांबर ट्रस्ट धर्मशाला में ठहरने के लिए 400 कमरे और सुबह के नाश्ते दोपहर के लंच और रात के भोजन की व्यवस्था होती है। इसी प्रकार अन्य कईं धर्मशालाएँ आसानी से मिल जाती हैं।

**English:** There are frequent buses from Kashmere Gate to Meerut. Then there are buses from Meerut to Hastinapur. There is also a dharamshala for people who have reached Hastinapur. The Shwetambar Trust dharamshala has 400 rooms for stay and breakfast, lunch and dinner. Similarly, many other dharamshalas are easily available.

## Group 4

**Hindi:** हस्तिनापुर में प्रक्षाल और पूजा अर्चना का समय सुबह 8 बजे से शाम 5 बजे तक है। यानी अगर साधारण तौर पर जो कुछ माँगा जाए, उससे कहीं ज्यादा मिल जाए और दिगम्बर जैन मंदिर में पूजा करने का समय सुबह सात बजे प्रारम्भ होता है। यानी ऐसा क्षेत्र, जहाँ कुछ असाधारण घटित हो या कोई चमत्कार हो जाए। बताते हैं कि तिजारा क्षेत्र के एक मशहूर वैद्य बिहारी लाल की पत्‍नी सरस्वती देवी ने तीन दिन का उपवास रखा था। लोगबाग दूर दूर से उनके दर्शन के लिए जाते थे।

**English:** The time of cleansing and worship in Hastinapur is from 8 am to 5 pm. That is, if you get more than what is normally asked for, and the time of worship in the Digambar Jain temple starts at 7 am. That is, an area where something extraordinary happens or a miracle happens. It is said that Saraswati Devi, the wife of a famous Vaidya Bihari Lal of the Tijara region, observed a three-day fast. People used to visit her from far away.

## Group 5

**Hindi:** इतना मिले कि आप सराबोर हो जाएँ। राजकुमार श्रेयंषकुमार को जब इस बात का ज्ञान हुआ तो उन्हें अपने पूर्वजों की अन्न जल त्यागने की प्रथा का स्मरण हो आया। हस्तिनापुर में जैन धर्म के चौबीस तीर्थंकरों में से सबसे पहले तीर्थंकर श्री आदिनाथ प्रभु ने अपने चार सौ दिनों के व्रत के पश्चात श्रेयंषकुमार के हाथों से गन्ने का रस ग्रहण कर अपने व्रत का समापन किया था। हस्तिनापुर में आदिनाथ भगवान दीक्षा लेने के 4 सौ दिनों बाद वैशाख शुक्ल तृतीया के दिन आए थे। भगवान आदिनाथ ने पोदनपुर और हस्तिनापुर राज्य अपने पुत्र बाहुबली को सौंप दिये थे।

**English:** Prince Shreyansh Kumar, when he came to know of this, remembered the practice of his ancestors of renouncing food and water. In Hastinapur, the first of the twenty-four Tirthankaras of Jainism, Tirthankara Sri Adinath Prabhu, after his fast of four hundred days, ended his fast by taking sugarcane juice from the hands of Shreyansh Kumar. In Hastinapur, Adinath came on the day of Vaishakha Shukla Tritiya, four hundred days after his initiation. Lord Adinath had handed over the kingdoms of Podanpur and Hastinapur to his son Bahubali.

## Group 6

**Hindi:** बाहुबली ने पोदनपुर पर शासन किया, जबकि उनके पुत्र सोमयश ने हस्तिनापुर पर, लेकिन समय के साथ वे प्राचीन स्तम्भ और मंदिर धीरे धीरे विलीन हो गए। बाहुबली के छोटे भाई श्रेयंषकुमार ने आदिनाथ भगवान का चरणाभिषेक किया था। श्रेयंषकुमार की स्मृति में रत्न स्तम्भ बनवाया था। वहाँ पर आदिनाथ भगवान के चरणपादुका भी स्थापित किये थे। खुदाई के दौरान 16 अगस्त, 1956 को निकली थी।

**English:** Bahubali ruled Podanpur, while his son Somayash ruled Hastinapur, but over time those ancient pillars and temples gradually merged. Bahubali's younger brother Shreyanshkumar performed the Charanabhisheka of Lord Adinath. Shreyansh Kumar had the Ratna Stambha built in his memory. There Adinath also installed the Charanpaduka of the Lord. The excavations were carried out on 16 August 1956.

## Group 7

**Hindi:** तिजारा अतिशय क्षेत्र में 24 तीर्थंकरों में से 8वें तीर्थंकर श्री चंद्र प्रभु भगवान की आराधना की जाती है। 24 तीर्थंकरो में से 20वें तीर्थंकर श्री मुनि सुव्रत स्वामी, 23वें तीर्थंकर पार्श्वनाथ भगवान और अंतिम तीर्थंकर श्री महावीर स्वामी ने भी इस स्थान को अपने चरणों से पावन किया। हस्तिनापुर में ही मुनि सुव्रत नाथ स्वामी, भगवान पार्श्वनाथ और भगवान महावीर स्वामी ने अपनी दिव्य वाणी में प्रवचन दिए। राजा शिवराज ने महावीर स्वामी के प्रवचन सुनकर जैन धर्म को अपनाया। महावीर स्वामी की स्मृति में राजा शिवराज ने हस्तिनापुर में एक स्तम्भ बनवाया।

**English:** In the Tijara Atishay Kshetra, the 8th Tirthankara Shri Chandra Prabhu Bhagwan is worshipped. Out of the 24 Tirthankars, the 20th Tirthankara Shri Muni Suvrat Swami, the 23rd Tirthankara Parshvanatha Bhagwan and the last Tirthankara Shri Mahavir Swami also sanctified this place with their feet. It was in Hastinapur that Muni Suvrat Nath Swami, Bhagwan Parshvanatha and Bhagwan Mahavir Swami preached in their Divine Vani. King Shivraj embraced Jainism after listening to Mahavir Swami's sermons. In memory of Mahavir Swami, King Shivraj built a pillar in Hastinapur.

## Group 8

**Hindi:** श्री शांतिनाथ भगवान, श्री कुंथनाथ भगवान और अरहनाथ भगवान के चार कल्याणक की स्मृति में भी यहाँ तीन स्तम्भ बनवाये गए। राजकुमार श्रेयंषकुमार ने आदिनाथ प्रभु से व्रत के समापन के लिए इक्षु रस ग्रहण करने की प्रार्थना की, जिसे उन्होंने स्वीकार किया। बाद में इस दिन को अक्षय तृतीया कहा जाने लगा। भारत में कुल 12 चक्रवर्ती सम्राट हुए। भारत के कुल 12, चक्रवर्ती सम्राट में से 6 का जन्म स्थान हस्तिनापुर है।

**English:** Three pillars were also built here in memory of the four Kalyanakas of Shri Shantinath Bhagwan, Shri Kunthanath Bhagwan and Arhanath Bhagwan. Prince Shreyansh Kumar prayed to Adinath Prabhu to take the juice of sugarcane for the conclusion of the fast, which he accepted. Later this day came to be called Akshaya Tritiya. There were a total of 12 Chakravartin Emperors in India. Hastinapur is the birthplace of 6 of the total 12 Chakravartin Emperors of India.

## Group 9

**Hindi:** यह हस्तिनापुर नगर पवित्र गंगा के किनारे मौजूद है। हस्तिनापुर कौरवों और पांडवों की राजधानी रह चुकी है। रामायण काल के परशुराम भी हस्तिनापुर में पैदा हुए। तिजारा क्षेत्र की मान्यता हस्तिनापुर में ही श्री शांतिनाथ प्रभु, कुंथनाथ प्रभु और श्री अरहनाथ प्रभु के बारह कल्याणक हुए। भगवान मल्लिनाथ का समवोशरन भी हस्तिनापुर में ही हुआ।

**English:** The city of Hastinapur is located on the banks of the holy Ganges. Hastinapur has been the capital of the Kauravas and Pandavas. Parshuram of the Ramayana period was also born in Hastinapur. The Tijara region is believed to be the same place where Sri Shantinatha Prabhu, Kunthanatha Prabhu and Sri Arhanatha Prabhu had twelve well-wishers. Lord Mallinatha was also cremated in Hastinapur.

## Group 10

**Hindi:** हस्तिनापुर में भगवान ने अपने प्रवचनों से 6 बड़े राजाओं को जैन धर्म का अनुयायी बनाया। सम्राट अशोक के एक वंशज ने भी अपने शासन काल के दौरान कई जैन मंदिर बनवाए। कार्तिक पूर्णिमा और वैशाख शुक्ल तृतीया को श्वेताम्बर जैन मंदिर में और कार्तिक शुक्ल से पूर्णिमा के बीच दिगम्बर जैन मंदिर में कार्यक्रम का आयोजन किया जाता है।

**English:** In Hastinapur, the Lord made 6 great kings followers of Jainism by his sermons. A descendant of Emperor Ashoka also built several Jain temples during his reign. The event is held at Svetambara Jain temple on Kartik Purnima and Vaishakh Shukla Tritiya and at Digambara Jain temple between Kartik Shukla and Purnima.