# sample-5.txt

## Group 1

**Hindi:** भारत में शहतूत mulberry, रेशम कीट का पालन कई स्थानों पर होता है, जैसे असम के पहाड़ी इलाकों, बंगाल, कोनूर, तमिलनाडु, देहरादून तथा हिमाचल प्रदेश। जब से देश में सिल्क बोर्ड Silk Board की स्थापना हुई। सिल्क उत्पादन में वैज्ञानिक तरीकों से काफी तरक्की हुई है। एक कैटरपिलर अपने वजन से 7, 000 9, 000 गुना शहतूत के पत्‍ते खा जाता है। 35 दिन तक शहतूत के पत्‍ते खाकर यह श्‍वेत स्लेटी रंग का कैटरपिलर बन जाता है और इसकी लंबाई 3, 1, 2 और चौड़ाई।

**English:** Mulberry mulberry, the silkworm, is reared in many places in India, such as the hills of Assam, Bengal, Konoor, Tamil Nadu, Dehradun, and Himachal Pradesh. Since the establishment of the Silk Board Silk Board in the country, scientific methods have made great strides in silk production. A caterpillar eats mulberry leaves 7,000 to 9,000 times its weight. By eating mulberry leaves for 35 days, it becomes a white-slit caterpillar with a length of 3, 1, 2, and width of 93C.

## Group 2

**Hindi:** 5 ग्राम होता है। प्रत्येक कीड़े में दो ग्रंथियाँ पायी जाती हैं, जो कीड़े के सिर वाले भाग में जबड़े के नीचे स्थित होती हैं। पहला तरल पदार्थ के रूप में, फिब्रॉयन, जो स्पिनरेट से निकलकर हवा के संपर्क में आकर सूख जाता है, और दूसरा पदार्थ सैरिसिन गोंद है। ये अंडे जलवायु के अनुसार, 3 से 7 दिन के भीतर, लारवा कैटरपिलर में परिवर्तित हो जाते हैं। उसके बाद यह कैटरपिलर, हल्के गुलाबी रंग का पारदर्शक कीड़ा बन जाता है।

**English:** There are 5 grams. Each insect\ u093C contains two glands, which are located below the jaw\ u093C in the head portion of the insect\ u093C. The first is the fluid, fibroin, which is released from the spinrate and dries up upon exposure to air, and the second is the substance saricin glue. These eggs are converted to larval caterpillars within 3 to 7 days, depending on the climate. The caterpillar then becomes a pale pink transparent insect\ u093C.

## Group 3

**Hindi:** जापान में हल्के हरे रंग के कोकून भी पैदा किए जाते हैं, जिसके कैटरपिलर हरी पत्‍तियाँ खाते हैं। एक नया कैटरपिलर केवल 1। 4 इंच लंबा होता है, परंतु यह इतना पेटू होता है कि अत्यधिक शहतूत की पत्‍तियाँ खाकर शीघ्र ही बढ़ने लगता है। तब इसकी खाने में रुचि कम हो जाती है। ऐसे कीड़ों का पालन, असम, बिहार, बंगाल, मणिपुर, उड़ीसा तथा त्रिपुरा में किया जाता है।

**English:** Light green cocoons are also grown in Japan, whose caterpillars feed on green leaves. A new caterpillar is only 1.4 inches long, but it is so gluttonous that it begins to grow quickly by eating excessive mulberry leaves. It then loses interest in eating. Such insects are reared in Assam, Bihar, Bengal, Manipur, Odisha, and Tripura.

## Group 4

**Hindi:** 1। 3 ग्राम होता है, जिसमें पतली परत का केवल 0। 4 हो जाती है। करीब 40 000 अंडों का वजन केवल एक आउंस के लगभग होता है। एक कोया का भार केवल 3 ग्राम होता है।

**English:** There are 1.3 grams, with a thin layer of only 0.4. About 40,000 eggs weigh only about an ounce. One koya weighs only 3 grams.

## Group 5

**Hindi:** रेशा बनाने की क्रिया में कीड़े का वजन कम हो जाता है और कोकून के भीतर कैटरपिलर क्राइसेलिस प्यूपा में बदल जाता है, और फिर दो सप्‍ताह में मॉथ moth बन जाता है। परंतु हम सेरीकल्चर फार्म में क्राइसेलिस को बाहर नहीं निकलने देते। ऐरी सिल्क के कोयों के खुले मुंह होने के कारण इनसे निकले हुए रेशों की रीलिंग नहीं कर सकते। केवल भारत ही ऐसा देश है जहाँ सुनहले पीले रंग का मूंगा रेशम पैदा किया जाता है। यह सुनहले रंग का रेशम मल्टीवोल्टाइन वर्ग के रेशम कीड़ों से प्राप्‍त होता है।

**English:** The fiber-forming process reduces the weight of the insect\ u093C and the caterpillar within the cocoon turns into the chrysalis pupa, and then into a moth moth in two weeks. But we do not allow the chrysalis to come out in the sericulture farm. Due to the open mouths of the eri silk coyotes, the fibers cannot be reeled. India is the only country where golden yellow coral silk is produced. This golden silk is obtained from the multivoltine class of silkworms\ u093C.

## Group 6

**Hindi:** एक रेशम का कीड़ा 46 मीटर प्रति घंटे की रफ्तार से रेशे का निर्माण करता है। यदि हम सूक्ष्मदर्शी microscope से इस महीन रेशे को देखें, तो ज्ञात होगा कि यह रेशा दो तंतुओं का बना होता है। अतः हम कह सकते हैं कि प्रत्येक रेशा मुख्यतया दो रासायनिक पदार्थों से बना है। रेशम का कीड़ा दोनों ग्रंथियों पर दबाव डालकर निरंतर रेशम के दो तंतु बनाता है। ये दो पतले रेशम के तंतु स्पिनिंग हैड में सैरिसिन द्वारा जुड़कर एक ही साथ बाहर निकलते हैं, जिसे वेब bave कहते हैं।

**English:** A silkworm\ u093C\ forms a fiber at a speed of 46 meters per hour. If we look at this fine fiber with a microscope, it will be known that this fiber is made up of two fibers. So, we can say that each fiber is mainly made up of two chemical substances. The silkworm\ u093C\ forms two continuous silk fibers by applying pressure on both the glands. These two thin silk fibers are joined by saricin in the spinning head and come out together, which is called webbave.

## Group 7

**Hindi:** ऐसा रेशम कीड़ा विशेषरूप से असम में पाया जाता है। इस रेशम कीड़े के कोकून बंद होते हैं और उन पर बाहरी परत Shell काफी पतली होती है। अब इस अवस्था में, रेशम कीट एक प्रकार के क्षारीय पदार्थ को निकालकर उसके द्‍वारा कोकून के कुछ भाग को घोलकर छिद्र बना देता है और इस छिद्र से कीड़ा कोकून से बाहर निकल आता है। उसके निकलने से पूर्व ही कोकून को हल्की भाप में रखकर रेशम कीट को कोकून के भीतर ही मार देते हैं। इस क्रिया को स्टोविंग stoving कहते हैं।

**English:** Such a silkworm\ u093C\ is found especially in Assam. The cocoons of this silkworm\ u093C\ are closed and the outer layer shell on them is very thin. Now in this stage, the silkworm extracts a kind of alkaline material by dissolving some part of the cocoon to make a hole and from this hole the worm\ u093C\ comes out of the cocoon. Before it comes out, the silkworm is put in a light steam and killed inside the cocoon. This action is called stowing stowing.

## Group 8

**Hindi:** स्टोविंग की क्रिया में रेशम कीट कोकून के भीतर ही मर जाता है, परंतु रेशम के रेशे या कोकून को भाप से किसी प्रकार का नुकसान नहीं पहुँचता। टसर रेशम कीट को कोकून के भीतर मारने की आवश्यकता नहीं। संभवतः इसके कोकून का रंग, पत्तों का टैनिन सोखने के कारण ही भूरा होता है। हमारे देश में चार प्रकार के रेशम पैदा किए जाते हैं। ये रेशम के रेशे तिकोने होते हैं और इनमें अणु श्रृंखलाएं, सूक्ष्म micro और स्थूल macro, तंतुकों fibrils के रूप में व्यवस्थित अवस्था में उपस्थित होती हैं।

**English:** In the process of stowing, the silkworm dies within the cocoon, but the silkworm or the cocoon is not harmed by steam. The tusser silkworm does not need to be killed within the cocoon. The colour of its cocoon is probably brown due to the absorption of the tannin of the leaves. Four types of silk are produced in our country. These silkworms are triangular and present in molecular chains, micro and macro, arranged as fibrils.

## Group 9

**Hindi:** प्रत्येक रेशे में करीब 75 फिब्रॉयन तथा 25 सैरिसिन होता है। परंतु टसर के रेशे, मल्बरी, सिल्क के रेशे की अपेक्षा, मोटे तथा सख्त होते हैं और इनमें सैरिसिन की मात्रा भी मूंगा तथा ऐरी रेशम से ज्यादा होती है। लच्छियों की चमक तथा कोमलता में अंतर को समझने के लिए यह जानना आवश्यक है कि प्रत्येक रेशा दो महीन तंतुओं brins से बनता है और ये तंतु सैरिसिन गोंद से जुड़े होते हैं। इन महीन तंतुओं को ब्रिन brin कहते हैं। इनके कोकून प्रायः अंडाकार, सख्त व भूरे रंग के होते हैं।

**English:** Each fiber contains about 75 fibroins and 25 saricins. However, tussar fibers are thicker and harder than mulberry and silk fibers and contain more saricin than coral and eri silk. To understand the difference in lustre and softness of silk, it is necessary to know that each fiber is made of two fine fibers brins and these fibers are\ u093C attached to saricin glue. These fine fibers are called brin brin. Their cocoons are often oval, hard, and brown.

## Group 10

**Hindi:** जापान तथा यूरोप में कोकून, क्रीम व हल्के पीले रंग के होते हैं, क्योंकि वहाँ पर कैटरपिलर कैस्टर, आयल, पौधों, castor oil plant के पत्‍ते खाकर अपने अंदर टैनिन tannin नामक पदार्थ सोख लेते हैं। भारत में सफेद कोकून के अतिरिक्‍त स्लेटी तथा हल्के भूरे रंग के कोये भी पाए जाते हैं। इन कोयों की विशेषता बहुरूपी रंग बदलना है। कैटरपिलर अपने बढ़ने की क्रिया में बार बार अपनी त्वचा बदलता है, ताकि वह बढ़ते हुए आकार को ढक सके। यह कहना अधिक उपयुक्‍त होगा कि पूरा तंतु बनाने में आठ अंक को वह करीब 12 लाख बार रेशम के धागे से लिखता है।

**English:** In Japan and Europe, cocoons are cream and light yellow in color, as caterpillars ingest tannin by eating castor, oil, plant, castor oil plant leaves. In India, apart from white cocoons, slatty and light brown coyotes are also found. These coyotes are characterized by polymorphic discoloration. The caterpillar changes its skin frequently in the process of growing so that it can cover the growing size. It is more appropriate to say that the eight digits are written about 1.2 million times with silk thread to form the entire fiber.

## Group 11

**Hindi:** चीन में रेशम के कीड़े से प्राप्‍त कोये प्रायः सफेद रंग के होते हैं, क्योंकि वहाँ पर कैटरपिलर सफेद शहतूत के पत्‍ते खाते हैं। टसर रेशम का कैटरपिलर शहतूत के पत्‍तों की जगह ओक oak पेड़ के पत्‍ते खाता है। यह सफेद या लाल रंग का रेशम है, जो मल्टीवोल्टाइन वर्ग के रेशम कीड़ों से प्राप्‍त होता है। इन कीड़ों के कोकून कुछ लंबे आकार के होते हैं। पड़ती और लंबे रेशे आसानी से मिल जाते हैं।

**English:** In China, coyotes derived from the silkworm\ u093C are often white in colour, as caterpillars eat white mulberry leaves. The tusser silk caterpillar eats oak leaves instead of mulberry leaves. This is white or red silk, derived from the multivoltine class of silkworms\ u093C. The cocoons of these insects\ u093Cs are somewhat longer.

## Group 12

**Hindi:** इस प्रकार, 30। मल्बरी, रेशम, टसर, ऐरी और मूंगा। हमारे देश में लगभग 90 शहतूत mulberry रेशम पैदा किया जाता है और शेष 10 वन्य सिल्क, wild silk, टसर, ऐरी तथा मूंगा पैदा किया जाता है। ऐसे रेशम कीट, जिनसे टसर रेशम प्राप्‍त होता है, देश के उष्ण तथा शीतोष्ण जलवायु वाले भागों में पैदा होते हैं। कश्मीर में यूनिवोल्टाइन तथा बाइवोल्टाइन रेशम कीट, पश्‍चिम बंगाल में बढ़िया, किस्म के मल्टीवोल्टाइन रेशम कीट तथा कर्नाटक में मल्टीवोल्टाइन रेशम कीट का पालन होता है।

**English:** Thus, mulberry, silk, tussar, arei, and coral. About 90 mulberry mulberry silk is produced in our country and the remaining 10 are wild silk, wild silk, tussar, arei, and coral. Such silkworms, from which tussar silk is derived, are produced in parts of the country with hot and temperate climates. Univoltine and bivoltine silkworms are reared in Kashmir, banyan in West Bengal, multivoltine silkworms in West Bengal, and multivoltine silkworms in Karnataka.

## Group 13

**Hindi:** कोकून का रंग व आकार, रेशम कीट के खाने और जलवायु पर, जिसमें उसका पालन किया जाता है, निर्भर करता है। एक कोकून का भार करीब 6।

**English:** The color and size of the cocoon depend on the silkworm's diet and the climate in which it is reared. A cocoon weighs about 6.