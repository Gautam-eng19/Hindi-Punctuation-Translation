# sample-1.txt

## Group 1

**Hindi:** गंगा किनारे। पतित पावनी गंगा हरिद्वार में पर्वतीय क्षेत्र को छोड़कर समतल भूमि में प्रवेश करती हैं। इसलिए हरिद्वार को गंगा द्वार भी कहते हैं। चलें गढ़ मुक्तेश्वर का गंगा मेला लक्सर से एक लाइन हरिद्वार तक गई है। गंगा नदी पर तैरती दीपमालाओं का दृश्य देखते ही बनता है।

**English:** On the banks of the Ganges. The fallen Pawni Ganga leaves the hilly region in Haridwar and enters the plains. Hence, Haridwar is also called Ganga Dwar. The Ganga Mela of Garh Mukteshwar is a line from Luxor to Haridwar. The view of the lamps floating on the river Ganges is spectacular.

## Group 2

**Hindi:** दक्षिण रेलवे के चेन्नै स्टेशन से धनुष्कोटि जाने वाली मुख्य लाइन पर चेन्नै से 35 मील की दूरी पर चेंगलपट स्टेशन है। चेंगलपट स्टेशन से एक लाइन अरकोनम तक जाती है। चेंगलपट स्टेशन से अरकोनम जाने वाली लाइन पर कांजीवरम स्टेशन है। मोक्ष उक्त लाइन के महू स्टेशन से भी एक लाइन उज्जैन को गई है। तब सबने एक राय से निर्णय लिया था।

**English:** Chengalpattu station is 35 miles from Chennai on the main line of Southern Railway from Chennai station to Dhanushkoti. A line from Chengalpattu station goes to Arakkonam. Kanjivaram station is on the line from Chengalpattu station to Arakkonam. A line from Mhow station of the said line has also gone to Ujjain. Then everyone decided unanimously.

## Group 3

**Hindi:** द्वारका चार धामों में एक धाम भी है। इसका नाम बनारस या वाराणसी भी है। पश्चिम रेलवे की सुरेंद्रनगर ओखा पोर्ट लाइन पर स्थित यह नगर समुद्र किनारे का स्टेशन है। मध्य रेलवे की मुंबई, भोपाल दिल्ली लाइन के भोपाल स्टेशन से एक लाइन उज्जैन जाती है। पश्चिम रेलवे की मुंबई, कोटा दिल्ली लाइन पर नागदा स्टेशन से एक बड़ी लाइन भी उज्जैन तक गई है।

**English:** Dwarka is also one of the Char Dhamas. It is also called Banaras or Varanasi. Situated on the Surendranagar Okha Port Line of the Western Railway, the town is a seaside station. A line from Bhopal Station of the Mumbai-Bhopal Delhi line of the Central Railway goes to Ujjain. A major line from Nagda Station on the Mumbai-Kota Delhi line of the Western Railway also goes to Ujjain.

## Group 4

**Hindi:** उत्तर रेलवे की मुगलसराय, लखनऊ लाइन के मुगलसराय स्टेशन से 128 मील की दूरी पर अयोध्या स्टेशन है। मुगलसराय से अमृतसर तथा देहरादून जाने वाली मुख्य रेलवे लाइन पर मुगलसराय स्टेशन से 7 मील पर काशी और उससे 4 मील आगे बनारस छावनी स्टेशन है। पूर्वोत्तर रेलवे की आगरा फोर्ट से गोरखपुर जाने वाली लाइन तथा पश्चिम रेलवे की मुंबई कोटा दिल्ली लाइन पर मथुरा स्टेशन है। उत्तर रेलवे की मुगलसराय से अमृतसर जाने वाली मुख्य लाइन पर स्टेशन है। पूर्वोत्तर रेलवे की एक लाइन, भटनी से तथा दूसरी छपरा से इलाहाबाद सिटी तक जाती है।

**English:** Ayodhya station is 128 miles from Mughalsarai station on the Mughalsarai-Lucknow line of the Northern Railway. Kashi is 7 miles from Mughalsarai station on the main railway line from Mughalsarai to Amritsar and Dehradun. Banaras Cantonment station is 4 miles ahead of it. Mathura station is on the Agra Fort-Gorakhpur line of the North Eastern Railway and Mumbai Kota Delhi line of the Western Railway. The station is on the main line from Mughalsarai to Amritsar of the Northern Railway. One line of the North Eastern Railway runs from Bhatni and the other from Chhapra to Allahabad City.

## Group 5

**Hindi:** इलाहाबाद के प्रयाग स्टेशन से भी एक सीधी लाइन काशी होते हुए बनारस छावनी तक जाती है। इस रास्ते से भी बनारस सिटी होते हुए छावनी जा सकते हैं। गाजियाबाद जिले के गढ़ मुक्तेश्वर में पतित पावनी गंगा के तट पर हर साल कार्तिक पूर्णिमा के अवसर पर लगने वाले उत्तर भारत के प्रसिद्ध और प्राचीन धार्मिक मेले का इतिहास लगभग पाँच हजार वर्ष पुराना है। भगवान राम के पूर्वज महाराज शिवि ने अपना वानप्रस्थ गढ़ मुक्तेश्वर में ही व्यतीत किया था। महाराज शिव ने भगवान परशुराम से यहाँ शिव मंदिर की स्थापना कराई थी।

**English:** A direct line also runs from Allahabad's Prayag station to Banaras Cantonment via Kashi. This route also leads to the cantonment via Banaras City. The history of the famous and ancient religious fair of North India held every year on the occasion of Kartik Purnima on the banks of the fallen Pawni Ganga at Garh Mukteshwar in Ghaziabad district goes back almost five thousand years. Maharaj Shiv, the ancestor of Lord Rama, spent his Vanprastha at Garh Mukteshwar. Maharaj Shiva established a Shiva temple here from Lord Parshuram.

## Group 6

**Hindi:** ज्ञात रहे कि शिव बल्लभपुर को ही अब गढ़ मुक्तेश्वर के नाम से जाना जाता है। गढ़ मुक्तेश्वर के विषय में कहा जाता है कि महाभारत के विनाशकारी युद्ध के बाद योगीराज, श्रीकृष्ण, धर्मराज, युधिष्ठिर व अर्जुन के मन में युद्ध की विभीषिका और नरसंहार को देखकर भारी ग्लानि हुई। उस समय गढ़ मुक्तेश्वर बल्लभ संप्रदाय का मुख्य केन्द्र था। गढ़ मुक्तेश्वर का नाम शिव बल्लभपुर पड़ा। स्टेशन का नाम कांजीवरम जरूर है, किंतु नगर का नाम कांचीपुरम है।

**English:** It may be recalled that Shiv Ballabhpur itself is now known as Garh Mukteshwar. It is said about Garh Mukteshwar that after the devastating war of Mahabharata, Yogiraj, Shri Krishna, Dharmaraj, Yudhishthira and Arjun were deeply saddened to see the horrors of the war and the massacre. At that time Garh Mukteshwar was the main center of the Ballabh sect. Garh Mukteshwar was named Shiv Ballabhpur. The name of the station is definitely Kanjivaram, but the name of the city is Kanchipuram.

## Group 7

**Hindi:** शिप्रा अथवा क्षिप्रा नदी के तट पर बसी महाकाल की यह उज्जैन नगरी पतित पावनी है। यह भगवान शंकर की प्रसिद्ध पुरी है। सप्तपुरियों के दर्शन से मिलता है। ये सातों, धर्मस्थल, सात नगरों या सप्तपुरियों के रूप में ग्रंथों में वर्णित हैं। ऐसा कहा गया है कि चतुर्मास में इन सप्तपुरियों का दर्शन मोक्ष प्रदान करने वाला होता है।

**English:** Situated on the banks of the Shipra or Kshipra river, this Ujjain city of Mahakal is Patit Pawani. This is the famous Puri of Lord Shankar. The Saptapuris are mentioned in the scriptures as Satas, Dharmasthala, Sat Nagas or Saptapuris. It is said that the sight of these Saptapuris in Chaturmas is the giver of salvation.

## Group 8

**Hindi:** खांडवी वन में भगवान परशुराम द्वारा स्थापित शिव बल्लभपुर नामक स्थान पर मुक्तेश्वर महादेव की पूजा, यज्ञ तथा पतित पावनी गंगा में स्नान करने और वहाँ पिंडदान करने से सभी संस्कार पूर्ण हो जाएँगे। प्राचीन काल में पितामह ब्रह्माजी ने कांची में माँ भगवती के दर्शन के लिए दुष्कर तपस्या की थी। भगवान कृष्ण ने इसे समुद्र के बीच में विशेष रूप से बसाया था, तब महालक्ष्मी हाथ में कमल धारण किए हुए उनके सामने प्रकट हुई थीं। कहते हैं कि उज्जैन में महाकाल को नमस्कार कर लेने पर फिर मृत्यु की चिंता नहीं रहती। हरिद्वार में प्रतिदिन शाम को होने वाली माँ गंगा की आरती के समय श्रद्धालुओं की भीड़ उमड़ पड़ती है।

**English:** At a place called Shiv Ballabhpur established by Lord Parshuram in the Khandvi forest, the worship of Mukteshwar Mahadev, Yajna and bathing in the fallen Pawni Ganga and performing Pinddaan there will complete all the rituals. In ancient times, Pitamah Brahmaji did hard penance for the darshan of Maa Bhagwati in Kanchi. Lord Krishna had specially installed it in the middle of the sea, then Mahalakshmi appeared before him wearing a lotus in her hand. It is said that after saluting Mahakal in Ujjain, there is no more worry of death. Devotees throng Haridwar every evening during the Aarti of Maa Ganga.

## Group 9

**Hindi:** मुख्य स्नान 13 नवंबर को है। गढ़ इस बार भी गढ़ मुक्तेश्वर में मेले की भरपूर गहमागहमी है और मुख्य स्नान के लिए श्रद्धालुओं की भारी भीड़ जुट रही है। गढ़मुक्तेश्वर हिंदुओं का पावन तीर्थ है। हिंदू धर्म में तीर्थ का बड़ा महत्व है। यूँ तो हर तीर्थ बड़ा और अहम है, लेकिन सात स्थानों की बड़ी महत्ता और मान्यता है।

**English:** The main bath is on 13 November. Garh Mukteshwar this time also has a huge crowd of devotees for the main bath. Garh Mukteshwar is a holy pilgrimage for Hindus. The pilgrimage is of great importance in Hinduism. However, every pilgrimage is big and important, but the seven places have great importance and recognition.

## Group 10

**Hindi:** वे इस सोच में पड़ गए कि युद्ध में मारे गए असंख्य कुटुम्बियों, बंधुओं व निर्दोष लोगों की आत्मा की शांति के लिए क्या उपाय या संस्कार किया जाए? अयोध्या पवित्र नदी सरयू के तट पर स्थित है। अयोध्या भगवान श्री राम के अवतार की पवित्र भूमि है। यमुना तट पर भगवान श्रीकृष्ण की अवतार भूमि का यह पवित्र नगर मथुरा है।

**English:** They wondered what measures or rites to perform for the peace of the souls of the innumerable relatives, brothers and innocent people killed in the war. Ayodhya is situated on the banks of the holy river Saryu. Ayodhya is the holy land of the incarnation of Lord Shri Ram. Mathura is the holy city of the land of the incarnation of Lord Krishna on the banks of the Yamuna.