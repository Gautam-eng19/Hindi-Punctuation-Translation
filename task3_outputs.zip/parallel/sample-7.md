# sample-7.txt

## Group 1

**Hindi:** सच कैलाशनाथ। कैलाशनाथ जी। जी। जी हाँ, साल भर तो पढ़ाई करते हैं। जब अख़बारों में तुम्हारा नाम पढ़ते हैं तो बहुत गर्व महसूस करते हैं।

**English:** True Kailashnath. Kailashnath ji. Yes, he reads 93C throughout the year. When he reads your name 93C every year, he feels very proud.

## Group 2

**Hindi:** और जैसे ही घर लौटें चले चलते हैं, आप प्रोफ़ेसर चौधरी जी के लिए पूछ रहे थे, न ये हैं। आज हम बहुत गुस्से में हैं, आज न हम खाएंगे, न पीएंगे। हम बहुत नाराज़ हैं। अपने भतीजे राजेश के लिए हमें तुम्हारी बड़ी बेटी बहुत भा गई है। आपने बच्चों को तभी तो राजेश का आज इतना नाम है और प्रेम भी तो इस साल एमबीए में अव्वल आया है।

**English:** And as soon as you go back home, you were asking for Prof.U.93C.Chaudhury ji, no, it is not. Today we are very angry, today we will not eat or drink. We are very angry. For our nephew Rajesh, we have liked your elder daughter very much. You children, Rajesh has so much name today and Prem has also come first in MBA this year.

## Group 3

**Hindi:** राजेश और प्रेम इतने इतने से थे, जब जीजी और जीजा जी का देहांत हुआ था। इन बच्चों का प्यार बड़ा कारोबार। इतनी कम उम्र में इतना बड़ा कारोबार संभालना कोई खेल नहीं है। लेकिन मैं तुम्हारा दिल जीतना खूब जानती हूँ। जब भी मैं तुमसे बात करना चाहती हूँ, कोई न कोई तुम्हें बुला लेता है।

**English:** Rajesh and Prem were there for so long when Jiji and Jija passed away. The love of these children is big business. It is no sport to manage such a big business at such a young age. But I know how to win your heart. Whenever I want to talk to you, someone calls you.

## Group 4

**Hindi:** अब तो तुम्हारी बारी है। तुम्हारी मीटिंग। दुल्हन चुनने की। इस वक्त प्रोफ़ेसर साहब अपने परिवार के साथ तीर्थ यात्रा पर रामटेकड़ी गए हुए हैं। यहाँ से उनकी बेटी की शादी है, ना, सब कुछ बेच के चले गए।

**English:** Now it's your turn. Your meeting. To choose the bride. At this moment, Prof. 93C.Saheb has gone to Ramtekad 93C on a pilgrimage with his family. From here his daughter's wedding, no, everything has been sold.

## Group 5

**Hindi:** भगवान ने मुझे सब कुछ दिया। अगर सब कुछ प्लान के मुताबिक गया। मैंने डॉक्टर चाची की बात सुन ली। मुझसे बोले कि रज़िया। तुझे बिज़नेस में लांच करने के लिए कितनी बड़ी फैक्ट्री लगा रहा है।

**English:** God gave me everything. If everything went according to plan. I listened to Doctor Aunt. He told me how big a factory u093C is setting up to launch you in Biz093Cness.

## Group 6

**Hindi:** न तो जैसे आपने कहा था, इस फैक्ट्री का देश भर में कोई मुकाबला नहीं होगा। लेकिन काका आप तो कह रहे थे कि आपको किसी हिल स्टेशन पर जाना था। वहां मैं उनकी बड़ी बेटी से मिला। उनकी बेटियां पूजा और निशा और पूजा। इन बच्चों की जिम्मेदारी निभाने के लिए आपने कॉलेज की पढ़ाई भी अधूरी छोड़ दी और एक छोटी सी नौकरी से शुरुआत की नंबर बढ़वाइए आप अपने चश्मे का मैडम, अमचूर की चटनी के साथ खाइये।

**English:** Neither, as you said, will this factory have any competition across the country. But uncle, you were saying that you had to go to a hill station. There I met his elder daughter. Pooja and Nisha and Pooja. To take care of these children, you left your college education incomplete and started with a small job.

## Group 7

**Hindi:** यहां तक अपने नंबर बढ़वाने अच्छा तो ये हलवा प्रेम भैया के लिए बनाया जा रहा है। किसी से कुछ बात मत करना और यहां बहू की फोटो देखते ही गुस्सा गुल पापा ने लाइब्रेरी की किताबें भेजी हैं और कहा है थैंक्यू। पापा। चौधरी से हुई पूजा बेटे। आप मुझे बता सकती हैं कि प्रोफ़ेसर चौधरी किस कमरे में ठहरे हुए हैं?

**English:** Even if you want to increase your number, this halwa is being made for Prem bhaiya. Don't talk to anyone and as soon as you see the daughter-in-law's photo here, angry Gul papa has sent the library books and said thank you. Papa. Pooja son from Chaudhary. You can tell me which room Prof.

## Group 8

**Hindi:** आप अपने को क्या समझ रही हैं? क्या कर रही है? बेटा, क्या निशा? क्या कहा? पंजाब।

**English:** What are you thinking of yourself? What are you doing? Son, what is Nisha? What did you say? Punjab.

## Group 9

**Hindi:** राजेश से। राजेश। सच कहती हूँ, भाई, साहब अपने राजेश बेटे की जितनी तारीफ़ की जाए, वो कम है। जब भी शादी की बात करो, वो टाल जाता है। तो फिर भी अपनी माँ की गोद में खेला है।

**English:** To Rajesh. Rajesh. Honestly, Bhai, Saheb, the amount of praise he gives to his Rajesh son is less. Whenever he talks about marriage, he avoids it. He has still played in his mother's lap.

## Group 10

**Hindi:** उसका बी। एस। पास किया है। बेटा, बीस साल तक इन आंसुओं को आँखों के अंदर रोक के रखा था। आज ये रुकने वाले नहीं हैं।

**English:** His B.S. passed. Son, these tears were held inside his eyes for twenty years. Today they are not going to stop.

## Group 11

**Hindi:** बेटी ये हैं। आज बेटा प्रेम, तुम शायद हम तीनों की हिस्ट्री नहीं जानते होगे। कॉलैबरेटर्स ने जब तक हम स्टोर रूम से वापस आएं, यह बिल का टोटल चेक कर देगी। मैनेजर साहब बिल का टोटल, आप एक बार फिर से चेक कर लीजिए। जल्दी कीजिए।

**English:** This is the daughter. Today, son Prem, you probably don't know the history of the three of us. The collaborators will check the total of the bill by the time we come back from the storeroom. Manager, sir, check the total of the bill once again. Hurry up.

## Group 12

**Hindi:** बेग़म। बच्ची को बस एक बार देखा। दिल में घर कर गई। वहां मम्मी। वहां मेरी मुलाकात।

**English:** Beg\ u093Cm | Just saw the baby girl once. Home in my heart. Mommy there. Meet me there.

## Group 13

**Hindi:** आज बड़ी देर तक चली। थोड़ी ही देर में मैच शुरू होने वाला है। इस बार छुट्टियों में हमने रामटेकड़ी जाने का फैसला किया है। पिछले दिनों प्रोफ़ेसर्स की कांफ्रेंस के लिए मैं पूना गया हुआ था। हम तीनों कॉलेज में एक साथ थे और बहुत मौज मस्ती किया करते थे।

**English:** Today it was late. The match is going to start late. This time during the holidays, we have decided to go to Ramtekad 93C. I was in Poona for the conference of Prof. 93Cers. All three of us were together in college and had a lot of fun.

## Group 14

**Hindi:** इनके भविष्य के लिए सिर्फ मेहनत को अपनी ज़िंदगी का लक्ष्य माना। लेकिन अगर उन्होंने भी एक बार इन कचौरियों को देख लिया ना तो अपना उपवास तोड़ देंगी। अगर मम्मी ने आपको रसोई में ये एक्सपेरीमेंट करते देख लिया, ना तो बड़ी नाराज़ होंगी। तू यहां देखा प्रेम। और हम आपको आँखों देखा।

**English:** For their future, only hard work was considered the goal of their life. But if they also saw these kachoris once, neither would they break their fast. If Mom saw you doing these experiments in the kitchen, neither would they be angry. You saw love here. And we saw your eyes.

## Group 15

**Hindi:** देखा मामा जी टफ़ी को भी पता है। वो भी इस किताब में पढ़कर पूजा नाम है। जब रामचंद्र जी ने शिव जी का धनुष तोड़ा तो परशुराम जी ने बड़े गरजते हुए पूछा कि ये धनुष किसने तोड़ा मैनेजर की कुर्सी पर बैठकर न जाने। रामचंद्र जी ने बड़ी सरलता से बड़े प्रेम भाव से उत्तर दिया। मगर प्रेम वो तो आज तक उस ममता से वंचित रहा।

**English:** See, Mama ji Tough 93C also knows. That is also the name of Pooja as read in this book. When Ramchandra ji broke Shiv ji's bow, Parashuram ji roared and asked who would not sit on the manager's chair to break this bow 93C. Ramchandra ji simply replied with love. But Prem ji has been deprived of that love till today.

## Group 16

**Hindi:** आज शाम को बड़े भैया की ससुराल वाले सगाई का शगुन लेकर आने वाले हैं। इम्तिहान के समय बगले झांकते हैं और फिर आ जाते हैं। अब आपके सामने आ रहे हैं। हम जा रहे हैं। हाल सुनाने जा रहे हैं।

**English:** This evening, my brother-in-law's in-laws are going to bring the engagement omen. At the time of the exam, the goats peek and then come. Now they are coming in front of you. We are going. We are going to tell the story.

## Group 17

**Hindi:** लोग कहते हैं, खूबसूरत। नहीं। फ़ॉरेन। बड़ा ही मीठा स्वभाव है। वो जिनकी गेंद की रफ़्तार हवा से भी तेज है।

**English:** People say, beautiful. No. F093Coren. Bad\ u093C is sweet nature. Those whose ball's rough\ u093C is faster than the wind.

## Group 18

**Hindi:** मगर घर का आँगन सूना है, वो चले गए। इतने अच्छे संस्कार दिए। राजेश का रिश्ता तय कर आए, बहू चुन ली और हमें खबर मिल रही है। कब से तेरी राह देख रही हैं। तेरा भैया।

**English:** But the courtyard of the house is sunny, they left. They gave such good rites. Rajesh's relationship came, the daughter-in-law chose and we are getting the news. Since when are you looking for your way. Your brother.

## Group 19

**Hindi:** ए। एस। चौबे जी, मथुरा की कचौड़ियों को भूल जाएंगे। तुम्हारे पापा के दोस्त निशा बेटी एक काम करेगी। आपसे कोई जीते तो बस निशा।

**English:** A.S. Chaubey ji, you will forget the Kachauds of Mathura. Your father's friend Nisha Beti will do one thing. If someone wins from you, then just Nisha.

## Group 20

**Hindi:** आपसे जीतना तो हम दोनों के बस के बाहर है। अब ऐसे में दोनों को मिलाएं भी तो कैसे? प्रोफ़ेसर। लड़कियां टोटल में अक्सर मार खा जाती हैं।

**English:** It's out of the box for both of us to win over you. Now if you combine the two, how? Prof.\ u093Cesor | Fight\ u093Cs who are often killed in total.